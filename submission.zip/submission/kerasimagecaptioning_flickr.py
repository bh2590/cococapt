from pickle import dump
from keras.preprocessing.image import load_img
from keras.preprocessing.image import img_to_array
from keras.applications.vgg16 import preprocess_input
from keras.models import Model
from os import listdir

### UNCOMMENT TO RUN DESIRED MODEl
from keras.applications.inception_v3 import InceptionV3
#from keras.applications.vgg16 import VGG16
#from keras.applications.inception_v3 import preprocess_input
#from keras.applications.resnet50 import ResNet50
#from keras.applications.resnet50 import preprocess_input

# extract features from each photo in the directory
def feature_extractor(directory):
    """
    For each photo in input directory, get features.
    :param directory:
    :return:
    """
    #model = VGG16()
    model = InceptionV3()
    #model = ResNet50()
    model.layers.pop()
    model = Model(inputs=model.inputs, outputs=model.layers[-1].output)
    print(model.summary())
    features = {}
    for i, name in enumerate(listdir(directory)):
        filename = directory + '/' + name
        image = load_img(filename, target_size=(224, 224))
        image = img_to_array(image)
        image = image.reshape((1, image.shape[0], image.shape[1], image.shape[2]))
        image = preprocess_input(image)
        feature = model.predict(image, verbose=0)
        image_id = name.split('.')[0]
        features[image_id] = feature
        print('%d > %s' % (i, name))
    return features

directory = 'Flicker8k_Dataset'
features = feature_extractor(directory)
print('Extracted Features: %d' % len(features))
dump(features, open('features_inceptionv3.pkl', 'wb'))


import string

def document_load(filename):
    file = open(filename, 'r')
    text = file.read()
    file.close()
    return text

def desc_load(doc):
    mapping = {}
    for line in doc.split('\n'):
        tokens = line.split()
        if len(line) < 2:
            continue
        image_id = tokens[0]
        image_desc = tokens[1:]
        image_id = image_id.split('.')[0]
        image_desc = ' '.join(image_desc)
        if image_id not in mapping:
            mapping[image_id] = []
        mapping[image_id].append(image_desc)
    return mapping

def desc_clean(descriptions):
    table = str.maketrans('', '', string.punctuation)
    for key, desc_list in descriptions.items():
        for i in range(len(desc_list)):
            desc = desc_list[i]
            desc = desc.split()
            desc = [word.lower() for word in desc]
            desc = [w.translate(table) for w in desc]
            desc = [word for word in desc if len(word)>1]
            desc = [word for word in desc if word.isalpha()]
            desc_list[i] =  ' '.join(desc)

def convert_to_vocab(descriptions):
    all_desc = set()
    for key in descriptions.keys():
        [all_desc.update(d.split()) for d in descriptions[key]]
    return all_desc

def desc_save(descriptions, filename):
    lines = []
    for key, desc_list in descriptions.items():
        for desc in desc_list:
            lines.append(key + ' ' + desc)
    data = '\n'.join(lines)
    file = open(filename, 'w')
    file.write(data)
    file.close()

filename = 'Flickr8k_text/Flickr8k.token.txt'
doc = document_load(filename)
descriptions = desc_load(doc)
print('Loaded: %d ' % len(descriptions))
desc_clean(descriptions)
vocabulary = convert_to_vocab(descriptions)
print('Vocabulary Size: %d' % len(vocabulary))
desc_save(descriptions, 'descriptions.txt')



from pickle import load
def load_doc(filename):
    text = open(filename, 'r').read()
    return text


def load_set(filename):
    doc = document_load(filename)
    dataset = []
    for line in doc.split('\n'):
        if len(line) < 1:
            continue
        identifier = line.split('.')[0]
        dataset.append(identifier)
    return set(dataset)

def load_clean_descs(filename, dataset):
    doc = document_load(filename)
    descriptions = {}
    for line in doc.split('\n'):
        tokens = line.split()
        image_id = tokens[0]
        image_desc = tokens[1:]
        if image_id in dataset:
            if image_id not in descriptions:
                descriptions[image_id] = []
            desc = 'startseq ' + ' '.join(image_desc) + ' endseq'
            descriptions[image_id].append(desc)
    return descriptions

def load_photo_features(filename, dataset):
    fp = open(filename, 'rb')
    all_features = load(fp)
    features = {k: all_features[k] for k in dataset}
    return features


filename = '/Users/girish.pai/PycharmProjects/cs231n-project-repo/Files/keras/KerasImgCapForFlickr/Flickr8k_text/Flickr_8k.trainImages.txt'
train = load_set(filename)
print('Dataset: %d' % len(train))
train_descriptions = load_clean_descs('descriptions.txt', train)
print('Descriptions: train=%d' % len(train_descriptions))
train_features = load_photo_features('features_inceptionv3.pkl', train)
print('Photos: train=%d' % len(train_features))


def to_lines(descriptions):
    all_desc = []
    for key, val in descriptions.items():
        [all_desc.append(d) for d in val]
    return all_desc

def make_tokenizer(descriptions):
    lines = to_lines(descriptions)
    tokenizer = Tokenizer()
    tokenizer.fit_on_texts(lines)
    return tokenizer

tokenizer = make_tokenizer(train_descriptions)
vocab_size = len(tokenizer.word_index) + 1
print('Vocab Size: %d' % vocab_size)

from numpy import array

from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.utils import to_categorical
from keras.models import Model
from keras.layers import Input, Dense, LSTM, Embedding, Dropout
from keras.layers.merge import add
from keras.callbacks import ModelCheckpoint

def load_doc(filename):
    text = open(filename, 'r').read()
    return text

def load_set(filename):
    doc = document_load(filename)
    dataset = []
    for line in doc.split('\n'):
        if len(line) < 1:
            continue
        identifier = line.split('.')[0]
        dataset.append(identifier)
    return set(dataset)

def load_clean_descriptions(filename, dataset):
    doc = document_load(filename)
    descriptions = {}
    for line in doc.split('\n'):
        tokens = line.split()
        image_id = tokens[0]
        image_desc = tokens[1:]
        # skip images not in the set
        if image_id in dataset:
            # create list
            if image_id not in descriptions:
                descriptions[image_id] = []
            desc = 'startseq ' + ' '.join(image_desc) + ' endseq'
            descriptions[image_id].append(desc)
    return descriptions

def load_photo_features(filename, dataset):
    all_features = load(open(filename, 'rb'))
    features = {k: all_features[k] for k in dataset}
    return features

def to_lines(descriptions):
    all_desc = []
    for key in descriptions.keys():
        [all_desc.append(d) for d in descriptions[key]]
    return all_desc

def create_tokenizer(descriptions):
    lines = to_lines(descriptions)
    tokenizer = Tokenizer()
    tokenizer.fit_on_texts(lines)
    return tokenizer

def max_length(descriptions):
    lines = to_lines(descriptions)
    lens = [len(d.split()) for d in lines]
    return max(lens)

def create_sequences(tokenizer, max_length, descriptions, photos):
    X1 = []
    X2 = []
    y = []
    for key, desc_list in descriptions.items():
        for desc in desc_list:
            seq = tokenizer.texts_to_sequences([desc])[0]
            for i in range(1, len(seq)):
                in_seq_t = seq[:i]
                out_seq_t = seq[i]

                in_seq = pad_sequences([in_seq_t], maxlen=max_length)[0]
                out_seq = to_categorical([out_seq_t], num_classes=vocab_size)[0]

                X1.append(photos[key][0])
                X2.append(in_seq)
                y.append(out_seq)
    return array(X1), array(X2), array(y)

def define_model(vocab_size, max_length):
    #inputs1 = Input(shape=(4096,)) # This is for VGG
    inputs1 = Input(shape=(2048,))  # This is for Inception V3
    fe1 = Dropout(0.5)(inputs1)
    fe2 = Dense(256, activation='relu')(fe1)
    inputs2 = Input(shape=(max_length,))
    se1 = Embedding(vocab_size, 256, mask_zero=True)(inputs2)
    se2 = Dropout(0.5)(se1)
    se3 = LSTM(256)(se2)
    decoder1 = add([fe2, se3])
    decoder2 = Dense(256, activation='relu')(decoder1)
    outputs = Dense(vocab_size, activation='softmax')(decoder2)
    model = Model(inputs=[inputs1, inputs2], outputs=outputs)
    model.compile(loss='categorical_crossentropy', optimizer='adam')
    print(model.summary())
    return model

filename = 'Flickr8k_text/Flickr_8k.trainImages.txt'
train = load_set(filename)
print('Dataset: %d' % len(train))
train_descriptions = load_clean_descs('descriptions.txt', train)
print('Descriptions: train=%d' % len(train_descriptions))
train_features = load_photo_features('features_inceptionv3.pkl', train)
print('Photos: train=%d' % len(train_features))
tokenizer = make_tokenizer(train_descriptions)
dump(tokenizer, open('tokenizer.pkl', 'wb'))
vocab_size = len(tokenizer.word_index) + 1
print('Vocabulary Size: %d' % vocab_size)
max_length = max_length(train_descriptions)
print('Description Length: %d' % max_length)
X1train, X2train, ytrain = create_sequences(tokenizer, max_length, train_descriptions, train_features)


filename = 'Flickr8k_text/Flickr_8k.devImages.txt'
test = load_set(filename)
print('Dataset: %d' % len(test))
test_descriptions = load_clean_descs('descriptions.txt', test)
print('Descriptions: test=%d' % len(test_descriptions))
test_features = load_photo_features('features_inceptionv3.pkl', test)
print('Photos: test=%d' % len(test_features))
X1test, X2test, ytest = create_sequences(tokenizer, max_length, test_descriptions, test_features)

model = define_model(vocab_size, max_length)
filepath = 'm-ep{epoch:03d}-loss{loss:.3f}-val_loss{val_loss:.3f}.h5'
#checkpoint = ModelCheckpoint(filepath, monitor='val_loss', verbose=1, save_best_only=True, mode='min')
checkpoint = ModelCheckpoint(filepath, monitor='val_loss', verbose=1, save_best_only=False, save_weights_only=False, mode='auto', period=1)

model.fit([X1train, X2train], ytrain, epochs=30, batch_size = 256, verbose=1, callbacks=[checkpoint], validation_data=([X1test, X2test], ytest))
#model.fit([X1train, X2train], ytrain, epochs=1, batch_size = 256, verbose=1, callbacks=[checkpoint], validation_data=([X1test, X2test], ytest))

from numpy import argmax
from pickle import load
from keras.models import load_model
from nltk.translate.bleu_score import corpus_bleu


def word_for_id(integer, tokenizer):
    """
    :param integer:
    :param tokenizer:
    :return:
    """
    retval = None
    for word, index in tokenizer.word_index.items():
        if index == integer:
            retval = word
            break
    return retval

def generate_desc(model, tokenizer, photo, max_length):
    desc_s = 'startseq'
    for i in range(0, max_length):
        sequence_temp = tokenizer.texts_to_sequences([desc_s])[0]
        sequence = pad_sequences([sequence_temp], maxlen=max_length)
        yhat = model.predict([photo, sequence], verbose=0)
        yhat = argmax(yhat)
        word = word_for_id(yhat, tokenizer)
        if word is None:
            break
        desc_s = desc_s + ' ' + word
        if word == 'endseq':
            break
    return desc_s

def evaluate_model(model, descriptions, photos, tokenizer, max_length):
    actual = []
    predicted = []
    for key, desc_list in descriptions.items():
        yhat = generate_desc(model, tokenizer, photos[key], max_length)
        references = [d.split() for d in desc_list]
        actual.append(references)
        predicted.append(yhat.split())
    print('BLEU-1: %f' % corpus_bleu(actual, predicted, weights=(1.0, 0, 0, 0)))
    print('BLEU-2: %f' % corpus_bleu(actual, predicted, weights=(0.5, 0.5, 0, 0)))
    print('BLEU-3: %f' % corpus_bleu(actual, predicted, weights=(0.3, 0.3, 0.3, 0)))
    print('BLEU-4: %f' % corpus_bleu(actual, predicted, weights=(0.25, 0.25, 0.25, 0.25)))


# filename = 'model-ep004-loss3.586-val_loss3.843.h5'
filename = 'm-ep005-loss2.892-val_loss3.646.h5'
model = load_model(filename)
# evaluate model
evaluate_model(model, test_descriptions, test_features, tokenizer, max_length)


def extract_features_fromfile(filename):
    #model = VGG16()
    model = InceptionV3()
    #model = ResNet50()
    model.layers.pop()
    model = Model(inputs=model.inputs, outputs=model.layers[-1].output)
    image = load_img(filename, target_size=(224, 224))
    image = img_to_array(image)
    image = image.reshape((1, image.shape[0], image.shape[1], image.shape[2]))
    image = preprocess_input(image)
    feature = model.predict(image, verbose=0)
    return feature

tokenizer = load(open('tokenizer.pkl', 'rb'))
max_length = 34
model = load_model(filename)

photo = extract_features_fromfile('example.jpg')
description = generate_desc(model, tokenizer, photo, max_length)
print(description)

model_json = model.to_json()
jsonfile = filename + '.txt'
print(jsonfile)
with open(jsonfile, "w") as text_file:
    text_file.write(model_json)
